import { Counter } from 'components/Counter';
import { Main } from 'components/Main';
import { Todo } from 'components/Todo';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

function App() {
  

  return (
   <>
     <BrowserRouter>
      <Routes>  
        <Route path='/' element={<Main />} />
        <Route path='/counter' element={<Counter />} />
        <Route path='/todo' element={<Todo />} />
      </Routes>
     </BrowserRouter>
   </>
  );
}

export default App;
