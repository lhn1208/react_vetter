import { Link } from "react-router-dom";
export const Main = () => {
  return (
    <>
        <Link to="/counter">Counter App</Link>
        <Link to="/todo">Todo List</Link>
    </>
  );
};