import styled from '@emotion/styled';
import { TodoItem } from './Todo/TodoItem/index';
const Container = styled.div`
  height:100vh;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  background-color:#eee;
`;
const Title = styled.h1`
  margin-bottom:32px;
`;


export const Todo = () => {
  return (
    <Container>
       <Title>Todo List</Title>
       <TodoItem label='리액트 공부하기' />
       <TodoItem label='운동하기' />
       <TodoItem label='책읽기' />
    </Container>
  );
};